#import "RCTViewManager.h"

@interface RCTMFBLoginManager : RCTViewManager <FBSDKLoginButtonDelegate>

@end
