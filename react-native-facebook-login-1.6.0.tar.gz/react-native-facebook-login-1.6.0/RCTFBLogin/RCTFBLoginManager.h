#import <React/RCTViewManager.h>

@interface RCTMFBLoginManager : RCTViewManager <FBSDKLoginButtonDelegate>

@end
